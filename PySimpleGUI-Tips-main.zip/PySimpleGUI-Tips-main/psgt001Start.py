import PySimpleGUI as sg

# simple demo of popup window
# https://www.pysimplegui.org/en/latest/#jump-start
# https://www.pysimplegui.org/en/latest/cookbook/#getting-started-copy-these-design-patterns

a= 2
b= 4
c= a * b
print ('Your answer is ',c)
#sg.popup('Your answer is '+str(c))