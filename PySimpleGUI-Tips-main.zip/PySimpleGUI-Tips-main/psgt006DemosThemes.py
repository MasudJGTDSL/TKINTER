import PySimpleGUI as sg

# https://www.pysimplegui.org/en/latest/#demo-programs
# https://github.com/PySimpleGUI/PySimpleGUI/tree/master/DemoPrograms

sg.theme_previewer(columns=6, scrollable=True)
    