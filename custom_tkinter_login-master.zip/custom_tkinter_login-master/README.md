# Amazing custom tkinter login

Download the code, install required dependencies, customize and run 😄.

## installation
- clone the project
- move to th project directory
- (optional) activate you virtual env if you have one.
- run `python -m pip install -r requirements.txt` to install all required dependencies.
